# Critical Minerals Mining Application

A comprehensive web-based platform for analyzing and visualizing critical mineral resources in Africa, with a focus on South Africa's strategic mineral reserves.

![Python](https://img.shields.io/badge/Python-3.12+-blue.svg)
![Flask](https://img.shields.io/badge/Flask-3.0.0-green.svg)
![License](https://img.shields.io/badge/License-Educational-yellow.svg)

---

## 🌍 Overview

This application addresses the significant data and information gaps in Africa's critical minerals sector by providing a centralized, dynamic platform for essential mineral data. It supports strategic planning through geospatial visualization, country profiles, and interactive analytics.

### Background

South Africa is a pivotal player in the global critical minerals landscape, holding significant reserves of:
- Platinum Group Metals (PGMs)
- Chromium
- Manganese
- Lithium
- Cobalt
- Graphite

This application aligns with South Africa's Critical Minerals and Metals Strategy (May 2025) to leverage these resources for industrialization and job creation.

---

## ✨ Key Features

### 🔐 Access Control System
- Role-Based Access Control (RBAC)
- Three user roles: Administrator, Investor, Researcher
- Secure login with password hashing
- Session management

### 💎 Mineral Database
- Comprehensive repository of critical minerals
- Market price tracking (USD per tonne)
- Detailed mineral profiles with production statistics
- Interactive charts and visualizations

### 🌍 Geographical Visualization
- Interactive maps using Folium
- Mining site locations with production data
- Country-specific site mapping
- Color-coded markers based on production volume

### 🏳️ Country Profiles
- Economic data (GDP, Mining Revenue)
- Mining contribution to GDP analysis
- Key projects information
- Historical production trends

### 📊 Interactive Analytics
- Production trend analysis (Plotly)
- Export value visualization
- Mineral price comparisons
- Country GDP vs Mining Revenue charts
- Production distribution analysis

---

## 🛠 Technology Stack

### Backend
- **Python 3.12+**
- **Flask 3.0.0**
- **Pandas 2.1.4**
- **Werkzeug 3.0.1**

### Frontend
- **HTML5/CSS3**
- **Bootstrap 5.3.0**
- **Font Awesome 6.4.0**
- **JavaScript (ES6+)**

### Visualization
- **Plotly 5.18.0**
- **Folium 0.15.1**

### Data Storage
- **CSV Files** (Flat-file database)

---

## 🚀 Quick Start

```bash
# Create virtual environment
python -m venv venv

# Activate virtual environment
# Windows:
venv\Scripts\activate
# Mac/Linux:
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Hash passwords (first time only)
python hash_passwords.py

# Run application
python app.py

# Open browser
# Navigate to: http://127.0.0.1:5000
